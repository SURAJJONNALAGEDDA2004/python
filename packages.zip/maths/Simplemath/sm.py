def add(*args):
  sum=0
  for i in args:
    sum=sum+i
  return sum

def mul(*args):
  sum=1
  for i in args:
    sum=sum*i
  return sum  

def subtract(a,b):
  c=a-b
  return c

def div(a,b):
  c=a/b
  return c
    