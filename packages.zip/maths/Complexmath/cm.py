def power(a,b):
  c=a**b
  return c

