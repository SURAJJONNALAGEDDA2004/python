import maths.Simplemath.sm as m
import maths.Complexmath.cm as c
print(m.add(2,3,4))
print(m.subtract(4,3))
print(m.mul(2,3,4))
print(m.div(4,2))
print(c.power(2,3))
from maths.Simplemath.sm import add
print(add(2,3,4,5))
from maths.Simplemath.sm import subtract
print(subtract(43,20))
from maths.Simplemath.sm import mul
print(mul(2,3))
from maths.Simplemath.sm import div
print(div(10,5))
