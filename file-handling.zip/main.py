"""import sqlite3
conn=sqlite3.connect("suraj.db")
#conn.execute("CREATE TABLE details(ID INT,NAME VARCAR(20),BRANCH VARCAR(20),YEAR INT);")
conn.execute("INSERT INTO details(ID,NAME,BRANCH,YEAR) VALUES (479,'KRANTHI','CSE',1),(007,'RITHVIK','CSE',1),(1433,'MANISH','CSE',1);")
cr=conn.cursor()
cr.execute('SELECT *  FROM details ')
result=cr.fetchall()
print(list(result))
for i in list(result):
  print("Name : ",i[1])
  print("Roll number : ",i[0])
  print("Branch: ",i[2])
  print("Year : ",i[3])"""

import sqlite3
conn=sqlite3.connect("clg.db")
#conn.execute("CREATE TABLE dtl(ID INT ,NAME VARCHAR(20),BRANCH VARCHAR(20),SPECALIZATION VARCHAR(20));")
#conn.execute("CREATE TABLE fees(ID INT ,YEAR INT, FEEDUE INT);")
conn.execute("INSERT INTO dtl VALUES (479,'SURAJ','CSE','IT'),(007,'RITHVIK','CSE','CORE'),(1433,'MANISH','CSE','AIML'),(1039,'ABBAS','CSE','CORE');")
conn.execute("INSERT INTO fees(ID,YEAR,FEEDUE) VALUES (479, 1,10000),(007,2,1000000),(1433,3,34532),(1039,4,83493);")
cr=conn.cursor()
c=conn.cursor()
cr.execute('SELECT *  FROM dtl')
c.execute('SELECT * FROM fees')
result=cr.fetchall()
res=c.fetchall()
print(list(result))
print(list(res))
cr.execute('SELECT NAME FROM dtl ')
f=cr.fetchall()
print(tuple(f))
"""conn.execute("CREATE TABLE stotal as SELECT * FROM dtl sd INNER JOIN fees fd ON sd.ID=fd.ID;")
conn.execute("UPDATE ")
cr.execute('SELECT ID,NAME,BRANCH,SPECALIZATION,YEAR,FEEDUE FROM stotal')
s=cr.fetchall()
print(list(s))"""

'''import sqlite3
a=sqlite3.connect('test.db')
#a.execute("CREATE TABLE asd(ID INT ,NAME VARCHAR(29) , ROLLNUMBER INT);")
a.execute("INSERT INTO asd(ID,NAME,ROLLNUMBER) VALUES (479,'KRANTHI',1),(007,'RITHVIK',1),(1433,'MANISH',1);")
cr=a.cursor()
cr.execute('SELECT * FROM asd')
result=cr.fetchall()
print(result)'''
